import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  ScrollView,
} from 'react-native';
import Home from './src/home.js';


const App = () => {
  return(
      <Home />
  );
}


export default App;
